﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cSharp_1
{
    public class Lek
    {
        public string NazwaLeku { get; set;}
    }
}
