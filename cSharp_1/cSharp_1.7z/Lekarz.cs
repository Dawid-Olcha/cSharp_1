﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace cSharp_1
{
    class Lekarz:Pracownik
    {
        public Lekarz()
        {
            NumerId = Interlocked.Increment(ref _pracownikIdValue);
            Imie = "John";
            Nazwisko = "Smith";
            Pesel = 12345678901;
        }

    }
}
