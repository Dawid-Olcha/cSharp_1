﻿using System;
using System.Collections.Generic;
using System.Text;

namespace cSharp_1
{
    class Pielegniarka:Pracownik
    {

    }
}
