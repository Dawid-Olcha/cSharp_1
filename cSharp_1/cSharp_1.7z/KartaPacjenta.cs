﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace cSharp_1
{
    class KartaPacjenta
    {
        public List<int> nrZlecenList = new List<int>();
        private static int _liczbaKP = 0;
        public Pacjent p;
        //public Wywiad _wywiad;     KLASA DO IMPLEMETACJI
        //public Wypis _wypis;   KLASA DO IMPLEMETACJI

        public int NrKP { get; set; }

        KartaPacjenta()
        {
            NrKP = Interlocked.Increment(ref _liczbaKP);


        }

    }
}
